
/****** Script for SelectTopNRows command from SSMS  ******/



/****** Script for SelectTopNRows command from SSMS  ******/
CREATE    procedure [dbo].[userslist_dups] as 
DROP TABLE IF EXISTS #userslisttemp;
select * into #userslisttemp from (
SELECT    [USERID]
      ,[FIRSTNAME]
      ,[LASTNAME]
      ,[EMAIL]
      ,[DATECREATED]
      ,[ACTIVEFLAG]
      ,[DIVISION]
      ,[TITLE]
      ,[CITY]
      ,[STATE]
      ,[WORKPHONE]
      ,[EXTENSION]
      ,[CELLPHONE]
      ,[RECRUITERFLAG]
      ,[SALESFLAG]
      ,max([api_fromDate]) [api_fromDate]
      ,max([api_toDate]) [api_toDate]
      ,max([LOAD_START]) [LOAD_START]
      ,max([LOAD_END]) [LOAD_END]
      ,max([DW_INSERT_TIME]) [DW_INSERT_TIME]
	  ,max([INIT_LOAD_DT]) [INIT_LOAD_DT]
      ,[PK_LKUP]
  FROM [RPT_JobDivaAPI].[USERS].[USERSLIST]
  group by 
  [USERID]
      ,[FIRSTNAME]
      ,[LASTNAME]
      ,[EMAIL]
      ,[DATECREATED]
      ,[ACTIVEFLAG]
      ,[DIVISION]
      ,[TITLE]
      ,[CITY]
      ,[STATE]
      ,[WORKPHONE]
      ,[EXTENSION]
      ,[CELLPHONE]
      ,[RECRUITERFLAG]
      ,[SALESFLAG]
	  ,PK_LKUP
	  ,[INIT_LOAD_DT]) a ;

	  drop table [USERS].[USERSLIST];

	  CREATE TABLE [USERS].[USERSLIST](
	[USERID] [numeric](18, 0) NOT NULL,
	[FIRSTNAME] [varchar](50) NULL,
	[LASTNAME] [varchar](50) NULL,
	[EMAIL] [varchar](100) NULL,
	[DATECREATED] [datetime] NULL,
	[ACTIVEFLAG] [varchar](1) NULL,
	[DIVISION] [varchar](100) NULL,
	[TITLE] [varchar](200) NULL,
	[CITY] [varchar](100) NULL,
	[STATE] [varchar](2) NULL,
	[WORKPHONE] [varchar](20) NULL,
	[EXTENSION] [varchar](20) NULL,
	[CELLPHONE] [varchar](20) NULL,
	[RECRUITERFLAG] [varchar](1) NULL,
	[SALESFLAG] [varchar](1) NULL,
	[api_fromDate] [datetime] NULL,
	[api_toDate] [datetime] NULL,
	[LOAD_START] [datetime] NULL,
	[LOAD_END] [datetime] NULL,
	[DW_INSERT_TIME] [datetime] NULL,
	[PK_LKUP] [varchar](100) NULL,
	[INIT_LOAD_DT] [datetime] NULL
)  ;
	  insert into [USERS].[USERSLIST] select *  from #userslisttemp;
go

