/****** Script for SelectTopNRows command from SSMS  ******/


CREATE    procedure DIVISIONSLIST_dups as 
DROP TABLE IF EXISTS #DIVISIONSLISTtemp;
select * into #DIVISIONSLISTtemp from (
SELECT   [DIVISIONID]
      ,[DIVISIONNAME]
      ,max([api_fromDate]) [api_fromDate]
      ,max([api_toDate]) [api_toDate]
      ,max([LOAD_START]) [LOAD_START]
      ,max([LOAD_END]) [LOAD_END]
      ,max([DW_INSERT_TIME]) [DW_INSERT_TIME]
 
  FROM [RPT_JobDivaAPI].[GEN].[DIVISIONSLIST]
  GROUP BY [DIVISIONID]
      ,[DIVISIONNAME])A;

	 DROP TABLE [RPT_JobDivaAPI].[GEN].[DIVISIONSLIST];

	 SELECT * INTO [RPT_JobDivaAPI].[GEN].[DIVISIONSLIST] FROM #DIVISIONSLISTtemp;

go

