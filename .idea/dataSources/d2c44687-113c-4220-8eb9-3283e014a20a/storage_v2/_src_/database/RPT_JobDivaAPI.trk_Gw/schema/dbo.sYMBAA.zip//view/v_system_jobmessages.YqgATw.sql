

  CREATE view v_system_jobmessages as  
 with o as  
 (
select * from ( select top 10000 *  from [SSISDB].[internal].[operation_messages]  where message_type in ( -1)  
 and cast(message_time as date) >=  dateadd(day,-30,GETDATE())    order by message_time desc )a
union
select * from ( select top 10000 *  from [SSISDB].[internal].[operation_messages]  where message_type in ( 40)  
 and cast(message_time as date) >=  dateadd(day,-30,GETDATE())    order by message_time desc )b
 union
select * from ( select top 10000 *  from [SSISDB].[internal].[operation_messages]  where message_type in (110)  
 and cast(message_time as date) >=  dateadd(day,-30,GETDATE())    order by message_time desc )c
 union
select * from ( select top 10000 *  from [SSISDB].[internal].[operation_messages]  where message_type in (120)  
 and cast(message_time as date) >=  dateadd(day,-30,GETDATE())    order by message_time desc )d
 union
select * from ( select top 10000 *  from [SSISDB].[internal].[operation_messages]  where message_type in ( 130)  
 and cast(message_time as date) >=  dateadd(day,-30,GETDATE())    order by message_time desc  )e
 )
-- select distinct operation_id from o
,e as  (select top 10000 * 
		from  [SSISDB].[internal].[event_messages] 
		order by    [event_message_id] desc )  


SELECT top 1000   message_time, message event_message,event_name, message_source_name , execution_duration,job_status , job_start_time ,job_end_time,object_name
  FROM  o o -- 12866505
  join  e  e    -- 12866502
  on  o.operation_id = e.operation_id and o.operation_message_id = e.event_message_id
  join (
  SELECT top 10000  [execution_id]
      ,[status] job_status
      ,[start_time] job_start_time
      ,[end_time] job_end_time
       
  FROM [SSISDB].[catalog].[executions]
  where [execution_id] in (select distinct operation_id from o) 
  order by job_end_time desc ) ex on
  ex.execution_id = o.operation_id
  left join  (select distinct operation_id, object_name from [SSISDB].[internal].[operations]) oo on oo.operation_id = o.operation_id
    left  join[SSISDB].[catalog].[executables]  ea
   on o.operation_id = ea.execution_id  and ea.[executable_guid] = e.message_source_id
     left  join [SSISDB].[catalog].[executable_statistics] exs
   on   ea.executable_id   = exs.executable_id 
  and ea.execution_id =exs.execution_id 
  -- on exm.event_message_id = om.operation_message_id 
 --where message_type in ( -1,40,110,120,130)

  go

