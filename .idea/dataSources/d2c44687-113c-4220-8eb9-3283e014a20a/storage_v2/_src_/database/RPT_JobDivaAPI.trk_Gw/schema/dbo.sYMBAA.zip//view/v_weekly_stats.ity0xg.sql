

CREATE view [dbo].[v_weekly_stats] as 


Select b.BDM, [JOB_PRIMARYSALESID], b.mtg_cnt, b.[date_issued_week]
	 
	   ,isnull([JOB_OPENINGS],0) [JOB_OPENINGS]
      ,isnull([JOB_FILLS],0)  [JOB_FILLS]
      ,isnull([SUB_INTERVIEW],0)  [SUB_INTERVIEW]
      ,isnull([SUB_HIRES],0)  [SUB_HIRES]
      ,isnull([1SUBMITTAL],0) [1SUBMITTAL]
      ,isnull([2SUBSNEEDED],0) [2SUBSNEEDED]
      ,isnull([SHORT],0) [SHORT]
      ,isnull([NOTCOVERED2],0) [NOTCOVERED2]
      ,isnull([COVERED2],0) [COVERED2]
      ,isnull([3SUBSNEEDED],0) [3SUBSNEEDED]
      ,isnull([SHORT_3SUBS],0) [SHORT_3SUBS]
      ,isnull([NOTCOVERED3],0) [NOTCOVERED3]
      ,isnull([COVERED3],0) [COVERED3]
      ,isnull([SUB_EXTERNALREJECTS],0) [SUB_EXTERNALREJECTS]
      ,isnull([SUB_INTERNALREJECTEDSUBMITTAL],0) [SUB_INTERNALREJECTEDSUBMITTAL] from  
 (
 
     
SELECT   convert(date,convert(date,DATEADD(wk, DATEDIFF(wk,0,[date]), 0))) dt , fullname,[PRIMARYSALESID]
  FROM [RPT_JobDivaAPI].[Auxiliary].[Calendar] a
  left join (SELECT Distinct   
 			firstname + ' ' + lastname fullname
			,[PRIMARYSALESID]
			 FROM [RPT_JobDivaAPI].[ACTIVITY].[ACTIVITYRECORDS] a 
					left join [USERS].[USERSLIST]  u 
						on a.userid = u.userid
					 where dateupdated >=  dateadd(week,-9,getdate())) b
			on 1=1
  where   [date]>=  dateadd(week,-9,getdate())
       and [date]<=   getdate()
     )cal 
	 left join (
SELECT   convert(date,DATEADD(wk, DATEDIFF(wk,0,[dt_gen]), 0)) date_issued_week 
      ,[bdm]
	  ,userid
      ,SUM([mtg_cnt]) mtg_cnt
  FROM [RPT_JobDivaAPI].[dbo].[v_sales_daily_meeting_cnt]
  group by  DATEADD(wk, DATEDIFF(wk,0,[dt_gen]), 0)   
      ,[bdm]
	  ,userid) b 
	    on cal.dt = b.date_issued_week 
		and cal.[PRIMARYSALESID] =  b.userid
	  left join 
	  (
	  Select 
		  [date_issued_week]
		,[JOB_PRIMARYSALESID]
	   ,isnull([JOB_OPENINGS],0) [JOB_OPENINGS]
      ,isnull([JOB_FILLS],0)  [JOB_FILLS]
      ,isnull([SUB_INTERVIEW],0)  [SUB_INTERVIEW]
      ,isnull([SUB_HIRES],0)  [SUB_HIRES]
      ,isnull([1SUBMITTAL],0) [1SUBMITTAL]
      ,isnull([2SUBSNEEDED],0) [2SUBSNEEDED]
      ,isnull([SHORT],0) [SHORT]
      ,isnull([NOTCOVERED2],0) [NOTCOVERED2]
      ,isnull([COVERED2],0) [COVERED2]
      ,isnull([3SUBSNEEDED],0) [3SUBSNEEDED]
      ,isnull([SHORT_3SUBS],0) [SHORT_3SUBS]
      ,isnull([NOTCOVERED3],0) [NOTCOVERED3]
      ,isnull([COVERED3],0) [COVERED3]
      ,isnull([SUB_EXTERNALREJECTS],0) [SUB_EXTERNALREJECTS]
      ,isnull([SUB_INTERNALREJECTEDSUBMITTAL],0) [SUB_INTERNALREJECTEDSUBMITTAL]
from v_weekly_job_stats ) a 


	  on cal.dt = a.date_issued_week and USERid = a.JOB_PRIMARYSALESID
go

