



CREATE VIEW [v_API_TO_RPT_LOADSTATS]
AS
SELECT DISTINCT    
   execs.execution_id
,folder_name
,project_name
,execs.package_name
,executable_name
,executed_as_name
,statistics_id
,execl.executable_id
,stat.execution_path
,start_time
,end_time
,execution_duration
,case execution_result
	when 0 then 'Success'
	when 1 then 'Failure'
	when 2 then 'Completion'
	when 3 then 'Cancelled'
end execution_result
,project_id

FROM       ( [SSISDB].[internal].[executions] execs 
		   INNER JOIN [SSISDB].[internal].[executable_statistics] stat 
           ON execs.[execution_id] = stat.[execution_id]) 
		   
		   INNER JOIN [SSISDB].[internal].[executables] execl
           ON stat.[executable_id] = execl.[executable_id] 
		    
  INNER JOIN (select * from [SSISDB].catalog.[event_messages] where message_time >= getdate()-15 ) AS EM 
 
on EM.operation_id = execs.[execution_id] 
 
WHERE      execs.[execution_id] in (SELECT id FROM [SSISDB].[internal].[current_user_readable_operations])
           OR (IS_MEMBER('ssis_admin') = 1)
           OR (IS_SRVROLEMEMBER('sysadmin') = 1)
           OR (IS_MEMBER('ssis_logreader') = 1)

go

