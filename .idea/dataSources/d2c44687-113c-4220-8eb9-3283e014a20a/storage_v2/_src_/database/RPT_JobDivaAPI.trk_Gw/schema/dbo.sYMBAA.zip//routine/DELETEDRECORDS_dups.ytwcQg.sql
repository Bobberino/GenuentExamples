/****** Script for SelectTopNRows command from SSMS  ******/

/****** Script for SelectTopNRows command from SSMS  ******/
Create    procedure [dbo].[DELETEDRECORDS_dups] as 
DROP TABLE IF EXISTS #DELETEDRECORDStemp;
select * into #DELETEDRECORDStemp from (


SELECT  [ACTIVITYID] 
      ,[DATEDELETED] 
 
      ,max([api_fromDate]) [api_fromDate]
      ,max([api_toDate]) [api_toDate]
 
      ,max([DW_INSERT_TIME]) [DW_INSERT_TIME]
      
  FROM [RPT_JobDivaAPI].[ACTIVITY].[DELETEDACTIVITYRECORDS] 
  GROUP BY  [ACTIVITYID] 
      ,[DATEDELETED] ) A ;

	  DROP TABLE  [RPT_JobDivaAPI].[ACTIVITY].[DELETEDACTIVITYRECORDS];

	  SELECT * INTO  [RPT_JobDivaAPI].[ACTIVITY].[DELETEDACTIVITYRECORDS] FROM #DELETEDRECORDStemp;
go

