/****** Script for SelectTopNRows command from SSMS  ******/

/****** Script for SelectTopNRows command from SSMS  ******/
create   procedure COMPANYRECORDS_dups as 
DROP TABLE IF EXISTS #COMPANYRECORDSrecordstemp;
select * into #COMPANYRECORDStemp from (
SELECT   [COMPANYID]
      ,[COMPANYNAME]
      ,[DATECREATED]
      ,[DATEUPDATED]
      ,[DATEUSERFIELDUPDATED]
      ,[PRIMARYOWNER]
      ,[COMPANYTYPE]
      ,[ADDRESS1]
      ,[ADDRESS2]
      ,[CITY]
      ,[STATE]
      ,[ZIPCODE]
      ,[COUNTRYID]
      ,[PHONE]
      ,[FAX]
      ,[URL]
      ,[EMAIL]
      ,max([api_fromDate]) [api_fromDate]
      ,max([api_toDate]) [api_toDate]
      ,max([LOAD_START]) [LOAD_START]
      ,max([LOAD_END]) [LOAD_END]
      ,max([DW_INSERT_TIME]) [DW_INSERT_TIME]
      ,[PK_LKUP]
  FROM [RPT_JobDivaAPI].[COMPANY].[COMPANYRECORDS]
  GROUP BY   [COMPANYID]
      ,[COMPANYNAME]
      ,[DATECREATED]
      ,[DATEUPDATED]
      ,[DATEUSERFIELDUPDATED]
      ,[PRIMARYOWNER]
      ,[COMPANYTYPE]
      ,[ADDRESS1]
      ,[ADDRESS2]
      ,[CITY]
      ,[STATE]
      ,[ZIPCODE]
      ,[COUNTRYID]
      ,[PHONE]
      ,[FAX]
      ,[URL]
      ,[EMAIL]
	  ,PK_LKUP) a;

	  DROP TABLE   [RPT_JobDivaAPI].[COMPANY].[COMPANYRECORDS];

	  SELECT * INTO   [RPT_JobDivaAPI].[COMPANY].[COMPANYRECORDS] FROM #COMPANYRECORDstemp;
go

