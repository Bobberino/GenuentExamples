/****** Script for SelectTopNRows command from SSMS  ******/
CREATE    procedure [dbo].[activityrecords_dups] as 
DROP TABLE IF EXISTS #activityrecordstemp;
select * into #activityrecordstemp from (

SELECT  distinct [ACTIVITYID]
      ,[DATECREATED]
      ,[DATEUPDATED]
      ,[DATEUSERFIELDUPDATED]
      ,[USERID]
      ,[PRIMARYSALESID]
      ,[CANDIDATEID]
      ,[JOBID]
      ,[CONTACTID]
      ,[ROLEID]
      ,[COMPANYID]
      ,[SUBMITTALFLAG]
      ,[REJECTFLAG]
      ,[INTERVIEWFLAG]
      ,[HIREFLAG]
      ,[SUBMITTALDATE]
      ,[REJECTDATE]
      ,[REJECTREASON]
      ,[INTERVIEWDATE]
      ,[INTERVIEW_TIMEZONEID]
      ,[STARTDATE]
      ,[ENDDATE]
      ,[TERMINATIONDATE]
      ,[TERMINATIONREASON]
      ,[POSITIONTYPE]
      ,[AGREEDBILLRATE]
      ,[BILLFREQUENCY]
      ,[AGREEDPAYRATE]
      ,[PAYFREQUENCY]
      ,[CURRENCY]
      ,[FEE_TYPE]
      ,[FEE_PERCENT]
      ,[FEE]

      ,max([api_fromDate]) [api_fromDate]
      ,max([api_toDate]) [api_toDate]
      ,max([LOAD_START]) [LOAD_START]
      ,max([LOAD_END]) [LOAD_END]
      ,max([DW_INSERT_TIME]) [DW_INSERT_TIME]
	  ,  CONCAT([ACTIVITYID],'_',[DATEUPDATED]) PK_LKUP
	  ,[VendorClassification]
	  	  ,	[LOCATION] 
		,[TermExcludeDate] 
	,[StartExclude] 
  FROM [RPT_JobDivaAPI].[ACTIVITY].[ACTIVITYRECORDS]
  group by 
   [ACTIVITYID]
      ,[DATECREATED]
      ,[DATEUPDATED]
      ,[DATEUSERFIELDUPDATED]
      ,[USERID]
      ,[PRIMARYSALESID]
      ,[CANDIDATEID]
      ,[JOBID]
      ,[CONTACTID]
      ,[ROLEID]
      ,[COMPANYID]
      ,[SUBMITTALFLAG]
      ,[REJECTFLAG]
      ,[INTERVIEWFLAG]
      ,[HIREFLAG]
      ,[SUBMITTALDATE]
      ,[REJECTDATE]
      ,[REJECTREASON]
      ,[INTERVIEWDATE]
      ,[INTERVIEW_TIMEZONEID]
      ,[STARTDATE]
      ,[ENDDATE]
      ,[TERMINATIONDATE]
      ,[TERMINATIONREASON]
      ,[POSITIONTYPE]
      ,[AGREEDBILLRATE]
      ,[BILLFREQUENCY]
      ,[AGREEDPAYRATE]
      ,[PAYFREQUENCY]
      ,[CURRENCY]
      ,[FEE_TYPE]
      ,[FEE_PERCENT]
      ,[FEE]
	  ,[VendorClassification]
	  ,[LOCATION] 
	,[TermExcludeDate] 
	,[StartExclude] ) a ;

	  drop table [RPT_JobDivaAPI].[ACTIVITY].[ACTIVITYRECORDS];

	  CREATE TABLE [ACTIVITY].[ACTIVITYRECORDS](
	[ACTIVITYID] [numeric](18, 0) NOT NULL,
	[DATECREATED] [datetime] NULL,
	[DATEUPDATED] [datetime] NULL,
	[DATEUSERFIELDUPDATED] [datetime] NULL,
	[USERID] [numeric](18, 0) NULL,
	[PRIMARYSALESID] [numeric](18, 0) NULL,
	[CANDIDATEID] [numeric](18, 0) NULL,
	[JOBID] [numeric](18, 0) NULL,
	[CONTACTID] [numeric](18, 0) NULL,
	[ROLEID] [varchar](50) NULL,
	[COMPANYID] [numeric](18, 0) NULL,
	[SUBMITTALFLAG] [varchar](2) NULL,
	[REJECTFLAG] [varchar](2) NULL,
	[INTERVIEWFLAG] [varchar](2) NULL,
	[HIREFLAG] [varchar](2) NULL,
	[SUBMITTALDATE] [datetime] NULL,
	[REJECTDATE] [datetime] NULL,
	[REJECTREASON] [varchar](max) NULL,
	[INTERVIEWDATE] [datetime] NULL,
	[INTERVIEW_TIMEZONEID] [varchar](100) NULL,
	[STARTDATE] [datetime] NULL,
	[ENDDATE] [datetime] NULL,
	[TERMINATIONDATE] [datetime] NULL,
	[TERMINATIONREASON] [varchar](200) NULL,
	[POSITIONTYPE] [varchar](100) NULL,
	[AGREEDBILLRATE] [varchar](20) NULL,
	[BILLFREQUENCY] [varchar](20) NULL,
	[AGREEDPAYRATE] [varchar](20) NULL,
	[PAYFREQUENCY] [varchar](20) NULL,
	[CURRENCY] [varchar](20) NULL,
	[FEE_TYPE] [varchar](20) NULL,
	[FEE_PERCENT] [varchar](100) NULL,
	[FEE] [varchar](20) NULL,
	[api_fromDate] [datetime] NULL,
	[api_toDate] [datetime] NULL,
	[api_param1] [varchar](100) NULL,
	[api_param2] [varchar](100) NULL,
	[api_param3] [varchar](200) NULL,
	[LOAD_START] [datetime] NULL,
	[LOAD_END] [datetime] NULL,
	[DW_INSERT_TIME] [datetime] NULL,
	[PK_LKUP] [varchar](100) NULL,
	[VendorClassification] [varchar](100) NULL,
	[INIT_LOAD_DT] [datetime] NULL,
	[LOCATION] [varchar](100) NULL,
	[TermExcludeDate] [varchar](100) NULL,
	[StartExclude] [varchar](100) NULL);

	  insert into [RPT_JobDivaAPI].[ACTIVITY].[ACTIVITYRECORDS] (
	  [ACTIVITYID]
      ,[DATECREATED]
      ,[DATEUPDATED]
      ,[DATEUSERFIELDUPDATED]
      ,[USERID]
      ,[PRIMARYSALESID]
      ,[CANDIDATEID]
      ,[JOBID]
      ,[CONTACTID]
      ,[ROLEID]
      ,[COMPANYID]
      ,[SUBMITTALFLAG]
      ,[REJECTFLAG]
      ,[INTERVIEWFLAG]
      ,[HIREFLAG]
      ,[SUBMITTALDATE]
      ,[REJECTDATE]
      ,[REJECTREASON]
      ,[INTERVIEWDATE]
      ,[INTERVIEW_TIMEZONEID]
      ,[STARTDATE]
      ,[ENDDATE]
      ,[TERMINATIONDATE]
      ,[TERMINATIONREASON]
      ,[POSITIONTYPE]
      ,[AGREEDBILLRATE]
      ,[BILLFREQUENCY]
      ,[AGREEDPAYRATE]
      ,[PAYFREQUENCY]
      ,[CURRENCY]
      ,[FEE_TYPE]
      ,[FEE_PERCENT]
      ,[FEE]
      ,[api_fromDate]
      ,[api_toDate]
      ,[LOAD_START]
      ,[LOAD_END]
      ,[DW_INSERT_TIME]
	  ,PK_LKUP
	  ,[VendorClassification]
	  ,[LOCATION] 
	  ,[TermExcludeDate] 
	  ,[StartExclude] )
	  
	  
	  
	  select 	  [ACTIVITYID]
      ,[DATECREATED]
      ,[DATEUPDATED]
      ,[DATEUSERFIELDUPDATED]
      ,[USERID]
      ,[PRIMARYSALESID]
      ,[CANDIDATEID]
      ,[JOBID]
      ,[CONTACTID]
      ,[ROLEID]
      ,[COMPANYID]
      ,[SUBMITTALFLAG]
      ,[REJECTFLAG]
      ,[INTERVIEWFLAG]
      ,[HIREFLAG]
      ,[SUBMITTALDATE]
      ,[REJECTDATE]
      ,[REJECTREASON]
      ,[INTERVIEWDATE]
      ,[INTERVIEW_TIMEZONEID]
      ,[STARTDATE]
      ,[ENDDATE]
      ,[TERMINATIONDATE]
      ,[TERMINATIONREASON]
      ,[POSITIONTYPE]
      ,[AGREEDBILLRATE]
      ,[BILLFREQUENCY]
      ,[AGREEDPAYRATE]
      ,[PAYFREQUENCY]
      ,[CURRENCY]
      ,[FEE_TYPE]
      ,[FEE_PERCENT]
      ,[FEE]
      ,[api_fromDate]
      ,[api_toDate]
      ,[LOAD_START]
      ,[LOAD_END]
      ,[DW_INSERT_TIME]
	  ,PK_LKUP
	  ,[VendorClassification]
	  ,[LOCATION] 
	  ,[TermExcludeDate] 
	  ,[StartExclude]  from 
	  #activityrecordstemp;


	--  insert into [ACTIVITY].[ACTIVITYRECORDS] select * from [stg_JobDivaAPI].[ACTIVITY].[stg_ACTIVITYRECORDS]   
go

