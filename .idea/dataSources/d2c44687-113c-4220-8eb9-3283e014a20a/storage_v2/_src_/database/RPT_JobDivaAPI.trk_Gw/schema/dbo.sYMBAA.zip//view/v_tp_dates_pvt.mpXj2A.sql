 
---- Unpivot the table.  
--SELECT VendorID, Employee, Orders  
--FROM   
--   (SELECT VendorID, Emp1, Emp2, Emp3, Emp4, Emp5  
--   FROM pvt) p  
--UNPIVOT  
--   (Orders FOR Employee IN   
--      (Emp1, Emp2, Emp3, Emp4, Emp5)  
--)AS unpvt;  
--GO  


CREATE  view v_tp_dates_pvt as 
SELECT distinct  [candidate_name]
,[candidateid]
,[JOB_JOB_JOBID] JOBID
,[JOB_JOBREF#]
,[date]
,[datetype]
from (
select [candidate_name]
,[candidateid]
,[JOB_JOB_JOBID]
,[JOB_JOBREF#]

,[ACT_SUBMITTALDATE]
,[SUB_SUBMITTALDATE]
,[ACT_REJECTDATE]
,[ACT_INTERVIEWDATE]
,[ACT_STARTDATE]
,[ACT_ENDDATE]
,[ACT_TERMINATIONDATE]
--,[EMP_EFFECTIVE_DATE]
,convert(Datetime,[EMP_BILLING_TERM_DATE]) [EMP_BILLING_TERM_DATE]
,[JOB_DATEISSUED]
,[JOB_JOB_STARTDATE]
,[JOB_JOB_ENDDATE]
FROM [RPT_JobDivaAPI].[dbo].[v_tp_jobactivity]) pvt
unpivot
([date] for [datetype] IN 
([ACT_SUBMITTALDATE]
,[SUB_SUBMITTALDATE]
,[ACT_REJECTDATE]
,[ACT_INTERVIEWDATE]
,[ACT_STARTDATE]
,[ACT_ENDDATE]
,[ACT_TERMINATIONDATE]
--,[EMP_EFFECTIVE_DATE]
,[EMP_BILLING_TERM_DATE]
,[JOB_DATEISSUED]
,[JOB_JOB_STARTDATE]
,[JOB_JOB_ENDDATE])) as unpvt
go

