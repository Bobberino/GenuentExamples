/****** Script for SelectTopNRows command from SSMS  ******/

/****** Script for SelectTopNRows command from SSMS  ******/
CREATE    procedure CANDIDATENOTERECORDS_dups as 
DROP TABLE IF EXISTS #CANDIDATENOTERECORDStemp;
select * into #CANDIDATENOTERECORDStemp from (


SELECT  [CANDIDATEID]
      ,[NOTEID]
      ,[ACTIONTYPE]
      ,[USERID]
      ,[CREATEDATE]
      ,[JOBID]
      ,[CONTACTID]
      ,[NOTEFIRST100CHARS]
      ,max([api_fromDate]) [api_fromDate]
      ,max([api_toDate]) [api_toDate]
      ,max([LOAD_START]) [LOAD_START]
      ,max([LOAD_END]) [LOAD_END]
      ,max([DW_INSERT_TIME]) [DW_INSERT_TIME]
      ,[PK_LKUP]
  FROM [RPT_JobDivaAPI].[NOTE].[CANDIDATENOTERECORDS]
  GROUP BY [CANDIDATEID]
      ,[NOTEID]
      ,[ACTIONTYPE]
      ,[USERID]
      ,[CREATEDATE]
      ,[JOBID]
      ,[CONTACTID]
      ,[NOTEFIRST100CHARS]
	  ,PK_LKUP) A ;

	  DROP TABLE  [RPT_JobDivaAPI].[NOTE].[CANDIDATENOTERECORDS] ;

	  SELECT * INTO  [RPT_JobDivaAPI].[NOTE].[CANDIDATENOTERECORDS] FROM #CANDIDATENOTERECORDStemp;
go

