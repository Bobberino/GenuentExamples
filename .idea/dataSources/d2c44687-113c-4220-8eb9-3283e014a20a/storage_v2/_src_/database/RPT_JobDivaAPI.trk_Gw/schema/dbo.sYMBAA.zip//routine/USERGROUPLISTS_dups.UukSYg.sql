/****** Script for SelectTopNRows command from SSMS  ******/



/****** Script for SelectTopNRows command from SSMS  ******/
CREATE    procedure USERGROUPLISTS_dups as 
DROP TABLE IF EXISTS #USERGROUPLISTStemp;
select * into #USERGROUPLISTStemp from (
SELECT   [USERID]
      ,[USERNAME]
      ,[GROUPLISTNAME]
      ,max([api_fromDate]) [api_fromDate]
      ,max([api_toDate]) [api_toDate]
      ,max([LOAD_START]) [LOAD_START]
      ,max([LOAD_END]) [LOAD_END]
      ,max([DW_INSERT_TIME]) [DW_INSERT_TIME]
      ,[PK_LKUP]
  FROM [RPT_JobDivaAPI].[USERS].[USERGROUPLISTS]
  group by  [USERID]
      ,[USERNAME]
      ,[GROUPLISTNAME]
	  ,pk_lkup) a ;

	  drop table  [RPT_JobDivaAPI].[USERS].[USERGROUPLISTS];
	  select * into  [RPT_JobDivaAPI].[USERS].[USERGROUPLISTS] from #USERGROUPLISTStemp;
go

