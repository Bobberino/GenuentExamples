/****** Script for SelectTopNRows command from SSMS  ******/

CREATE view v_tp_bill as 
with jobs as (
SELECT distinct    [candidate_name]
      ,[city]
   --   ,[DATECREATED]
   --   ,[email]
      ,[candidateid]
      ,[cohort]
      ,[ACT_ACTIVITYID]
   --   ,[SUB_ACTIVITYID]
      ,[sub_SUBMITTALFLAG]
      ,[sub_INTERNALSUBMITTALFLAG]
      ,[ACT_DATECREATED]
      ,[ACT_DATEUPDATED]
   --   ,[ACT_DATEUSERFIELDUPDATED]
    --  ,[ACT_USERID]
      ,[ACT_PRIMARYSALESID]
   --   ,[ACT_CANDIDATEID]
   --   ,[JOB_CANDIDATE_NAME]
   --   ,[ACT_CONTACTID]
     
      ,[ACT_COMPANYID]
      ,[ACT_SUBMITTALFLAG]
      ,[ACT_REJECTFLAG]
      ,[ACT_INTERVIEWFLAG]
      ,[ACT_HIREFLAG]
      ,[ACT_SUBMITTALDATE]
      ,[SUB_SUBMITTALDATE]
      ,[ACT_REJECTDATE]
      ,[ACT_REJECTREASON]
      ,[ACT_INTERVIEWDATE]
      
      ,[ACT_STARTDATE]
      ,[ACT_ENDDATE]
      ,[ACT_TERMINATIONDATE]
      ,[ACT_TERMINATIONREASON]
      ,[ACT_POSITIONTYPE]
      ,[SUB_AGREEDBILLRATE]
      ,[ACT_AGREEDBILLRATE]
      ,[ACT_BILLFREQUENCY]
      ,[SUB_AGREEDPAYRATE]
      ,[ACT_AGREEDPAYRATE]
      ,[ACT_PAYFREQUENCY]

      ,[ACT_LOCATION]
    --  ,[ACT_StartExclude]
   --   ,[EMP_EMPLOYEEID]
  
    --  ,[EMP_EMP_JOBID]
    --  ,[EMP_EMP_ACTIVITYID]
 
 
 
     -- ,[EMP_EMP_STATUS]
 
    
 
      ,[JOB_JOB_JOBID]
      ,[JOB_JOBREF#]
    --  ,[JOB_OPTIONALREFERENCENO]
      ,[JOB_DIVISIONID]
      ,[JOB_DIVISION]
      ,[JOB_PRIMARYRECRUITERID]
      ,[JOB_JOB_PRIMARYSALESID]
   --   ,[JOB_JOB_COMPANYID]
   --   ,[JOB_COMPANY]
      ,[JOB_PRIMARYOWNERID]
  --    ,[JOB_JOB_CONTACTID]
  --    ,[JOB_CONTACTFIRSTNAME]
  --    ,[JOB_CONTACTLASTNAME]
      ,[JOB_DATEISSUED]
  --    ,[JOB_JOB_DATEUSERFIELDUPDATED]
  --    ,[JOB_PRIORITY]
      ,[JOB_JOB_DATEUPDATED]
      ,[JOB_JOB_STARTDATE]
      ,[JOB_JOB_ENDDATE]
      ,[JOB_JOB_POSITIONTYPE]
      ,[JOB_MAXALLOWEDSUBMITTALS]
      ,[JOB_STATUS]
      ,[JOB_JOBTITLE]
      ,[JOB_OPENINGS]
      ,[JOB_FILLS]
     
   
      ,[JOB_HIRINGMANAGER]
      ,[USER_PRIMARYRECRUITER]
      ,[USER_PRIMARYSALESPERSON]
  
      
  FROM [RPT_JobDivaAPI].[dbo].[v_tp_jobactivity]
  where JOB_DIVISION <> 'GTOD Test' and act_startdate is not null 
  and job_status <> 'IGNORED' and ACT_TERMINATIONDATE is null )

  select j.* ,c.*, r.firstname + ' ' + r.lastname rostername 
  from [dbo].[v_tp_cal]  c left join 
     [dbo].[v_tp_roster] r on 1=1 
	 left join jobs j on r.candidateid = j.candidateid 
	 where week between ACT_STARTDATE and isnull(ACT_ENDDATE,ACT_TERMINATIONDATE)
go

