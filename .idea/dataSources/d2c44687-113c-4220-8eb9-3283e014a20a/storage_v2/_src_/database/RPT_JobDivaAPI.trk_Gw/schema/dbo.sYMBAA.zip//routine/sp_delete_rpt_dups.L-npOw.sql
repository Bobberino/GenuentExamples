 CREATE procedure [dbo].[sp_delete_rpt_dups] as 
 -- use when reloading all records into rpt
exec RPT_JobDivaAPI.dbo.jobrecoprds_dups;
exec RPT_JobDivaAPI.dbo.activityrecords_dups;
exec RPT_JobDivaAPI.dbo.candidateactions_dups;
exec RPT_JobDivaAPI.dbo.CANDIDATERECORDS_dups;
exec RPT_JobDivaAPI.dbo.COMPANYRECORDS_dups;
exec RPT_JobDivaAPI.dbo.CONTACTRECORDS_dups;
exec RPT_JobDivaAPI.dbo.DIVISIONSLIST_dups;
exec RPT_JobDivaAPI.dbo.CANDIDATENOTERECORDS_dups;
exec RPT_JobDivaAPI.dbo.CONTACTNOTERECORDS_dups;
exec RPT_JobDivaAPI.dbo.TASKRECORDS_dups;
exec RPT_JobDivaAPI.dbo.USERGROUPLISTS_dups;
exec RPT_JobDivaAPI.dbo.userslist_dups;
exec RPT_JobDivaAPI.dbo.submittalactivity_dups;
exec RPT_JobDivaAPI.dbo.contactactions_dups;
exec RPT_JobDivaAPI.dbo.DELETEDRECORDS_dups;
 go

