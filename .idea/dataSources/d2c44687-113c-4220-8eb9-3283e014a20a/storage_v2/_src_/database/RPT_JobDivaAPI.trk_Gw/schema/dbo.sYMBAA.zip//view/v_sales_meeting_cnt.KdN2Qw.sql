 create view   v_sales_meeting_cnt  as 



WITH cal AS
     ( 
SELECT   convert(date,[Date]) dt 
  FROM [RPT_JobDivaAPI].[Auxiliary].[Calendar]
  where   [Date]>=  dateadd(week,-9,getdate())
       and [Date]<=   getdate()
     )


,
bdm as (
SELECT  distinct [USERFIRSTNAME]+ ' ' + [USERLASTNAME] BDM
FROM [RPT_JobDivaAPI].[dbo].[v_sales_meetings]
where actiontype in (	  'Client Appointment - F2F'
						, 'Client Appointment - F2F - NEW'
						, 'Client Job Launch Call'
						, 'Talent Path Class Visit'
						, 'Talent Path Consultants Presented'
						, 'Talent Path Intro - F2F Meeting'
						, 'Talent Path Opportunity - Call'
						, 'Talent Path Opportunity - F2F Meeting')
and actiondate >= dateadd(week,-9,getdate()))

,mtg as (
SELECT  distinct  convert(date,actiondate) mtg_dt
				 ,[USERFIRSTNAME]+ ' ' + [USERLASTNAME] BDM
				 ,count(distinct convert(varchar(60),([actiondate]))+[ACTIONTYPE]+convert(varchar(60),[CONTACTID])+[COMPANYNAME]) meeting_cnt

FROM [RPT_JobDivaAPI].[dbo].[v_sales_meetings]
where actiontype in (	  'Client Appointment - F2F'
						, 'Client Appointment - F2F - NEW'
						, 'Client Job Launch Call'
						, 'Talent Path Class Visit'
						, 'Talent Path Consultants Presented'
						, 'Talent Path Intro - F2F Meeting'
						, 'Talent Path Opportunity - Call'
						, 'Talent Path Opportunity - F2F Meeting')
and actiondate >= dateadd(week,-9,getdate())
group by  convert(date,actiondate)  
				 ,[USERFIRSTNAME]+ ' ' + [USERLASTNAME]  )

  select a.dt_gen, a.bdm , isnull(meeting_cnt,0) mtg_cnt
  From 
	  (SELECT convert(date,a.dt) dt_gen, BDM 
	  FROM cal a 
	  left join bdm b on 1=1  


	  ) a 
 left join mtg on a.dt_gen=mtg_dt and mtg.bdm = a.bdm

  	  --OPTION (MAXRECURSION 0) 
 go

