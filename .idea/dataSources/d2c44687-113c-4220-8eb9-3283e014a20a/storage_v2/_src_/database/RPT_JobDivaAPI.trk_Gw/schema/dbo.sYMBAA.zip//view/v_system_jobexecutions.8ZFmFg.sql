    



--select * from v_system_jobexecutions

		   
   
 CREATE VIEW v_system_jobexecutions
AS
(
		SELECT TOP 1000000
			 j.name AS 'JobName'
			,enabled
			,CASE run_status
				WHEN 0
					THEN 'Failed'
				WHEN 1
					THEN 'Successful'
				WHEN 3
					THEN 'Cancelled'
				WHEN 4
					THEN 'In Progress'
				END AS JobStatus
			,message job_run_message
			,msdb.dbo.agent_datetime(run_date, run_time) AS 'RunDateTime'
			,((run_duration / 10000 * 3600 + (run_duration / 100) % 100 * 60 + run_duration % 100 + 31) / 60) AS 'RunDurationMinutes'
			--,stop_execution_date
	  FROM  msdb.dbo.sysjobs j
		INNER JOIN    msdb.dbo.sysjobhistory h ON j.job_id = h.job_id
		
--	left join 	(SELECT sj.name, sja.job_id
--   , sja.stop_execution_date
--FROM msdb.dbo.sysjobactivity AS sja
--INNER JOIN msdb.dbo.sysjobs AS sj ON sja.job_id = sj.job_id
-- ) SJA
--         ON J.job_id = SJA.job_id
		--where j.enabled = 0   --Only Enabled Jobs
		--and j.name = 'TestJob' --Uncomment to search for a single job
		/*
and msdb.dbo.agent_datetime(run_date, run_time) 
BETWEEN '12/08/2012' and '12/10/2012'  --Uncomment for date range queries
*/
	-- WHERE msdb.dbo.agent_datetime(run_date, run_time) >= dateadd(day, - 30, getdate())
			where step_id = 0
		ORDER BY JobName
			,RunDateTime DESC
		)



go

