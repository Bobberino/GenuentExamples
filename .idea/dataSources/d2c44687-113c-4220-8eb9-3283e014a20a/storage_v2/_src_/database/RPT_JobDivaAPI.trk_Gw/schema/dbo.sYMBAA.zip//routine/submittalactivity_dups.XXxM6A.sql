
/****** Script for SelectTopNRows command from SSMS  ******/
CREATE    procedure [dbo].[submittalactivity_dups] as 
DROP TABLE IF EXISTS #submittalactivitytemp;
select * into #submittalactivitytemp from (

SELECT  distinct [ACTIVITYID]
      ,[USERID]
      ,[USERFIRSTNAME]
      ,[USERLASTNAME]
      ,[PRIMARYSALESID]
      ,[CANDIDATEID]
      ,[CANDIDATEFIRSTNAME]
      ,[CANDIDATELASTNAME]
      ,[CANDIDATEEMAIL]
      ,[JOBID]
      ,[JOBREFERENCENUMBER]
      ,[JOBTITLE]
      ,[CONTACTID]
      ,[CONTACTFIRSTNAME]
      ,[CONTACTLASTNAME]
      ,[COMPANYID]
      ,[COMPANYNAME]
      ,[ACTIVITYDATE]
      ,[SUBMITTALFLAG]
      ,[INTERVIEWFLAG]
      ,[HIREFLAG]
      ,[INTERNALSUBMITTALFLAG]
      ,[SUBMITTALDATE]
      ,[INTERNALREJECTDATE]
      ,[INTERVIEWDATE]
      ,[EXTERNALREJECTDATE]
      ,[STARTDATE]
      ,[ENDDATE]
      ,[TERMINATIONDATE]
      ,[AGREEDBILLRATE]
      ,[AGREEDPAYRATE]
      ,[BILLFREQUENCY]
      ,[PAYFREQUENCY]
      ,[CURRENCY]
      ,[FEE_TYPE]
      ,[FEE_PERCENT]
      ,[FEE]
, max([api_toDate]) [api_toDate]
, max([api_fromDate]) [api_fromDate]
      ,'' as  [LOAD_START]
      ,'' as [LOAD_END]
    , '' as [DW_INSERT_TIME]
	  --, max([DW_INSERT_TIME]) [DW_INSERT_TIME]
	   ,'' PK_LKUP
  FROM [RPT_JobDivaAPI].[ACTIVITY].[submittalactivity]
  group by 
  [ACTIVITYID]
      ,[USERID]
      ,[USERFIRSTNAME]
      ,[USERLASTNAME]
      ,[PRIMARYSALESID]
      ,[CANDIDATEID]
      ,[CANDIDATEFIRSTNAME]
      ,[CANDIDATELASTNAME]
      ,[CANDIDATEEMAIL]
      ,[JOBID]
      ,[JOBREFERENCENUMBER]
      ,[JOBTITLE]
      ,[CONTACTID]
      ,[CONTACTFIRSTNAME]
      ,[CONTACTLASTNAME]
      ,[COMPANYID]
      ,[COMPANYNAME]
      ,[ACTIVITYDATE]
      ,[SUBMITTALFLAG]
      ,[INTERVIEWFLAG]
      ,[HIREFLAG]
      ,[INTERNALSUBMITTALFLAG]
      ,[SUBMITTALDATE]
      ,[INTERNALREJECTDATE]
      ,[INTERVIEWDATE]
      ,[EXTERNALREJECTDATE]
      ,[STARTDATE]
      ,[ENDDATE]
      ,[TERMINATIONDATE]
      ,[AGREEDBILLRATE]
      ,[AGREEDPAYRATE]
      ,[BILLFREQUENCY]
      ,[PAYFREQUENCY]
      ,[CURRENCY]
      ,[FEE_TYPE]
      ,[FEE_PERCENT]
      ,[FEE]
	  ) a ;

	  drop table [RPT_JobDivaAPI].[ACTIVITY].[SUBMITTALACTIVITY];
	  CREATE TABLE [ACTIVITY].[SUBMITTALACTIVITY](
	[ACTIVITYID] [numeric](18, 0) NOT NULL,
	[USERID] [numeric](18, 0) NULL,
	[USERFIRSTNAME] [varchar](50) NULL,
	[USERLASTNAME] [varchar](50) NULL,
	[PRIMARYSALESID] [numeric](18, 0) NULL,
	[CANDIDATEID] [numeric](18, 0) NULL,
	[CANDIDATEFIRSTNAME] [varchar](50) NULL,
	[CANDIDATELASTNAME] [varchar](50) NULL,
	[CANDIDATEEMAIL] [varchar](100) NULL,
	[JOBID] [numeric](18, 0) NULL,
	[JOBREFERENCENUMBER] [varchar](50) NULL,
	[JOBTITLE] [varchar](100) NULL,
	[CONTACTID] [numeric](18, 0) NULL,
	[CONTACTFIRSTNAME] [varchar](50) NULL,
	[CONTACTLASTNAME] [varchar](50) NULL,
	[COMPANYID] [numeric](18, 0) NULL,
	[COMPANYNAME] [varchar](200) NULL,
	[ACTIVITYDATE] [datetime] NULL,
	[SUBMITTALFLAG] [varchar](2) NULL,
	[INTERVIEWFLAG] [varchar](2) NULL,
	[HIREFLAG] [varchar](2) NULL,
	[INTERNALSUBMITTALFLAG] [varchar](2) NULL,
	[SUBMITTALDATE] [datetime] NULL,
	[INTERNALREJECTDATE] [datetime] NULL,
	[INTERVIEWDATE] [datetime] NULL,
	[EXTERNALREJECTDATE] [datetime] NULL,
	[STARTDATE] [datetime] NULL,
	[ENDDATE] [datetime] NULL,
	[TERMINATIONDATE] [datetime] NULL,
	[AGREEDBILLRATE]  [varchar](20) NULL,
	[AGREEDPAYRATE] [varchar](20) NULL,
	[BILLFREQUENCY] [varchar](20) NULL,
	[PAYFREQUENCY] [varchar](20) NULL,
	[CURRENCY] [varchar](20) NULL,
	[FEE_TYPE] [varchar](20) NULL,
	[FEE_PERCENT] [varchar](100) NULL,
	[FEE] [varchar](20) NULL,
	[api_fromDate] [datetime] NULL,
	[api_toDate] [datetime] NULL,
	[LOAD_START] [datetime] NULL,
	[LOAD_END] [datetime] NULL,
	[DW_INSERT_TIME] [datetime] NULL,
	[PK_LKUP] [varchar](100) NULL
);


insert  into [RPT_JobDivaAPI].[ACTIVITY].[SUBMITTALACTIVITY] ([ACTIVITYID]
      ,[USERID]
      ,[USERFIRSTNAME]
      ,[USERLASTNAME]
      ,[PRIMARYSALESID]
      ,[CANDIDATEID]
      ,[CANDIDATEFIRSTNAME]
      ,[CANDIDATELASTNAME]
      ,[CANDIDATEEMAIL]
      ,[JOBID]
      ,[JOBREFERENCENUMBER]
      ,[JOBTITLE]
      ,[CONTACTID]
      ,[CONTACTFIRSTNAME]
      ,[CONTACTLASTNAME]
      ,[COMPANYID]
      ,[COMPANYNAME]
      ,[ACTIVITYDATE]
      ,[SUBMITTALFLAG]
      ,[INTERVIEWFLAG]
      ,[HIREFLAG]
      ,[INTERNALSUBMITTALFLAG]
      ,[SUBMITTALDATE]
      ,[INTERNALREJECTDATE]
      ,[INTERVIEWDATE]
      ,[EXTERNALREJECTDATE]
      ,[STARTDATE]
      ,[ENDDATE]
      ,[TERMINATIONDATE]
      ,[AGREEDBILLRATE]
      ,[AGREEDPAYRATE]
      ,[BILLFREQUENCY]
      ,[PAYFREQUENCY]
      ,[CURRENCY]
      ,[FEE_TYPE]
      ,[FEE_PERCENT]
      ,[FEE]
      ,[api_fromDate]
      ,[api_toDate]
      ,[LOAD_START]
      ,[LOAD_END]
      ,[DW_INSERT_TIME]
      ,[PK_LKUP])
	  select [ACTIVITYID]
      ,[USERID]
      ,[USERFIRSTNAME]
      ,[USERLASTNAME]
      ,[PRIMARYSALESID]
      ,[CANDIDATEID]
      ,[CANDIDATEFIRSTNAME]
      ,[CANDIDATELASTNAME]
      ,[CANDIDATEEMAIL]
      ,[JOBID]
      ,[JOBREFERENCENUMBER]
      ,[JOBTITLE]
      ,[CONTACTID]
      ,[CONTACTFIRSTNAME]
      ,[CONTACTLASTNAME]
      ,[COMPANYID]
      ,[COMPANYNAME]
      ,[ACTIVITYDATE]
      ,[SUBMITTALFLAG]
      ,[INTERVIEWFLAG]
      ,[HIREFLAG]
      ,[INTERNALSUBMITTALFLAG]
      ,[SUBMITTALDATE]
      ,[INTERNALREJECTDATE]
      ,[INTERVIEWDATE]
      ,[EXTERNALREJECTDATE]
      ,[STARTDATE]
      ,[ENDDATE]
      ,[TERMINATIONDATE]
      ,[AGREEDBILLRATE]
      ,[AGREEDPAYRATE]
      ,[BILLFREQUENCY]
      ,[PAYFREQUENCY]
      ,[CURRENCY]
      ,[FEE_TYPE]
      ,[FEE_PERCENT]
      ,[FEE]
      ,[api_fromDate]
      ,[api_toDate]
      ,[LOAD_START]
      ,[LOAD_END]
      ,[DW_INSERT_TIME]
      ,[PK_LKUP]
	  from #submittalactivitytemp;
go

