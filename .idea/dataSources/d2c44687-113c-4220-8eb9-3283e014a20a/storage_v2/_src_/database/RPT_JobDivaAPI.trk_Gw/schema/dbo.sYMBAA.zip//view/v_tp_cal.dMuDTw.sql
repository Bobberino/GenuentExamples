

/****** Script for SelectTopNRows command from SSMS  ******/
CREATE view [dbo].[v_tp_cal] as 

SELECT distinct  DATEADD(wk, DATEDIFF(wk,0,[Date]), 0) week
      --,[Year]
      --,[Quarter]
      --,[Month]
      --,[Week]
      --,[Day]
      --,[DayOfYear]
      --,[Weekday]
      --,[Fiscal_Year]
      --,[Fiscal_Quarter]
      --,[Fiscal_Month]
      --,[KindOfDay]
      --,[Description]
	  ,SUM(case when daytype = 'Workday' then 8 else 0 end) over (partition by [WEEKofyear],[year] order by year,[WEEKofyear] ) workablehours 
  FROM [RPT_JobDivaAPI].[dbo].[DateDimension]
  where year = 2019 -- year >= 2018 and year <=2020 
  and weekday between 2 and 6 and daytype = 'Workday'

go

