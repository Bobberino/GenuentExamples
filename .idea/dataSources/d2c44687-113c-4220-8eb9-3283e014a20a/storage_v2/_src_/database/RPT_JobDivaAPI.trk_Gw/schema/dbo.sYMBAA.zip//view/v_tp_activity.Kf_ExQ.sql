
 CREATE view [dbo].[v_tp_activity] as 
	 Select sm.*, isnull(follow_up,'Generic') FOLLOW_UP
				from [dbo].[v_sales_meetings] sm
				left join (
						select contactid,'TP Follow Up' as follow_up, min(actiondate) actiondate 
						FROM [RPT_JobDivaAPI].[dbo].[v_sales_tp_meetings]
						GROUP BY CONTACTID ) tpf
				on sm.contactid = tpf.contactid and sm.actiondate>=tpf.actiondate
				where  
				-- sm.contactid = '26200393' and 
				sm.contactid in 
					(select contactid 
					 FROM [RPT_JobDivaAPI].[dbo].[v_sales_tp_meetings]) -- tp contacts

 go

