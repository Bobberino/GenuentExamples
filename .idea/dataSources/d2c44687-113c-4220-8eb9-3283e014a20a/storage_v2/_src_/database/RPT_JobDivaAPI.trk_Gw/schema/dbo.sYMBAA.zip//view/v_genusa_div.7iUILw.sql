
  create view v_genusa_div as 
  select DivisionID, DivisionName   
  FROM [GEN].[DIVISIONSLIST]
  where divisionname like '%GENUSA%'
  go

