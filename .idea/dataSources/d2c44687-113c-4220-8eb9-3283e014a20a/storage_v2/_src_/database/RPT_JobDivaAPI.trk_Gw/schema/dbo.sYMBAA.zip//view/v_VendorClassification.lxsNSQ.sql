/****** Script for SelectTopNRows command from SSMS  ******/
 CREATE view v_VendorClassification as 
select * from(
SELECT distinct   [JOBID]
      ,[CONTACTID]
      ,[COMPANYID]
      ,[VendorClassification]
  FROM [RPT_JobDivaAPI].[ACTIVITY].[ACTIVITYRECORDS]
  where [VendorClassification] is not null
  --order by COMPANYID
  -- JOBID = 10872989 all null except vendor classification.
) a 
  --left join 

  -- (
  --SELECT distinct   [JOBID]
     
  --    ,[COMPANYID]
  --    ,[VendorClassification]
  --FROM [RPT_JobDivaAPI].[ACTIVITY].[ACTIVITYRECORDS]
  --where [VendorClassification] is not null
  -----order by COMPANYID
  --) b

  --on a.jobID = b.jobid
  --and b.companyid = a.companyid
  --and a.vendorclassification= b.vendorclassification
go

