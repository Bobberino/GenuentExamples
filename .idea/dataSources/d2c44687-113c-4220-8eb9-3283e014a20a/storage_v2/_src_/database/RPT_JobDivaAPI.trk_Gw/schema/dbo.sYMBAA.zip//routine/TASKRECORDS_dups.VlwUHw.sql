/****** Script for SelectTopNRows command from SSMS  ******/

CREATE    procedure TASKRECORDS_dups as 
DROP TABLE IF EXISTS #TASKRECORDStemp;
select * into #TASKRECORDStemp from (


SELECT  [ID]
      ,[RECRUITERID]
      ,[CUSTOMERID]
      ,[CANDIDATEID]
      ,[CREATORID]
      ,[EVENTDATE]
      ,[TITLE]
      ,[COMPLETED]
      ,[ASSIGNEDTO]
      ,[CREATEDBY]
      ,[TASKTYPE]
      ,[PRIVATE]
      ,[DATECREATED]
      ,[LASTMODIFIED]
      ,max([api_fromDate]) [api_fromDate]
      ,max([api_toDate]) [api_toDate]
      ,max([LOAD_START]) [LOAD_START]
      ,max([LOAD_END]) [LOAD_END]
      ,max([DW_INSERT_TIME]) [DW_INSERT_TIME]
      ,[PK_LKUP]
  FROM [RPT_JobDivaAPI].[TASK].[TASKRECORDS]
  group by
   [ID]
      ,[RECRUITERID]
      ,[CUSTOMERID]
      ,[CANDIDATEID]
      ,[CREATORID]
      ,[EVENTDATE]
      ,[TITLE]
      ,[COMPLETED]
      ,[ASSIGNEDTO]
      ,[CREATEDBY]
      ,[TASKTYPE]
      ,[PRIVATE]
      ,[DATECREATED]
      ,[LASTMODIFIED]
	  ,pk_lkup) a ;

  drop table [RPT_JobDivaAPI].[TASK].[TASKRECORDS];

  select * into [RPT_JobDivaAPI].[TASK].[TASKRECORDS] from  #TASKRECORDStemp;
go

