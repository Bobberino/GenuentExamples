/****** Script for SelectTopNRows command from SSMS  ******/
CREATE PROCEDURE SP_DELETE_ALL_TABLES AS 

SELECT  'DELETE ' + [TABLE_CATALOG] +'.'+ 
       [TABLE_SCHEMA] +'.'+
       [TABLE_NAME] +';'
    
  FROM [JobDivaAPI].[INFORMATION_SCHEMA].[TABLES]
  where [TABLE_NAME] not in ('METRICS','SYSDIAGRAMS')

  UNION

  SELECT  'DELETE ' + [TABLE_CATALOG] +'.'+ 
       [TABLE_SCHEMA] +'.'+
       [TABLE_NAME] +';'
    
  FROM [STG_JobDivaAPI].[INFORMATION_SCHEMA].[TABLES]
  where [TABLE_NAME] not in ('METRICS','SYSDIAGRAMS')


  UNION 
  
  SELECT 'DELETE ' + [TABLE_CATALOG] +'.'+ 
       [TABLE_SCHEMA] +'.'+
       [TABLE_NAME] +';'
    
  FROM [RPT_JobDivaAPI].[INFORMATION_SCHEMA].[TABLES]
  where [TABLE_NAME] not in ('METRICS','SYSDIAGRAMS')
go

