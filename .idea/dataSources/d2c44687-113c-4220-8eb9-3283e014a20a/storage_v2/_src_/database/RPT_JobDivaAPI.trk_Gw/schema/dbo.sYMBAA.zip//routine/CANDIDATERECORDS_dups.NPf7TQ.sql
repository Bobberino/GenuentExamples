/****** Script for SelectTopNRows command from SSMS  ******/

CREATE   procedure [dbo].[CANDIDATERECORDS_dups] as 
DROP TABLE IF EXISTS #CANDIDATERECORDStemp;
select * into #CANDIDATERECORDStemp from (





SELECT   [CANDIDATEID]
      ,[FIRSTNAME]
      ,[LASTNAME]
      ,[ADDRESS1]
      ,[ADDRESS2]
      ,[CITY]
      ,[STATE]
      ,[ZIPCODE]
      ,[WORKPHONE]
      ,[WORKPHONE_EXT]
      ,[HOMEPHONE]
      ,[CELLPHONE]
      ,[FAX]
      ,[EMAIL]
      ,[ALTERNATEEMAIL]
      ,[DATEUPDATED]
      ,[DATEPROFILEUPDATED]
      ,[DATEUSERFIELDUPDATED]
      ,[CURRENTSALARY]
      ,[CURRENTSALARYPER]
      ,[PREFERREDSALARYMIN]
      ,[PREFERREDSALARYPER]
      ,[RESUMECOUNT]
      ,[DATECREATED]
      ,max([api_fromDate]) [api_fromDate]
      ,max([api_toDate]) [api_toDate]
      ,max([LOAD_START]) [LOAD_START]
      ,max([LOAD_END]) [LOAD_END]
      ,max([DW_INSERT_TIME]) [DW_INSERT_TIME]
      ,[PK_LKUP]
  FROM [RPT_JobDivaAPI].[CANDIDATE].[CANDIDATERECORDS]
  GROUP BY [CANDIDATEID]
      ,[FIRSTNAME]
      ,[LASTNAME]
      ,[ADDRESS1]
      ,[ADDRESS2]
      ,[CITY]
      ,[STATE]
      ,[ZIPCODE]
      ,[WORKPHONE]
      ,[WORKPHONE_EXT]
      ,[HOMEPHONE]
      ,[CELLPHONE]
      ,[FAX]
      ,[EMAIL]
      ,[ALTERNATEEMAIL]
      ,[DATEUPDATED]
      ,[DATEPROFILEUPDATED]
      ,[DATEUSERFIELDUPDATED]
      ,[CURRENTSALARY]
      ,[CURRENTSALARYPER]
      ,[PREFERREDSALARYMIN]
      ,[PREFERREDSALARYPER]
      ,[RESUMECOUNT]
      ,[DATECREATED]
 
      ,[PK_LKUP]) A ;

DROP TABLE [RPT_JobDivaAPI].[CANDIDATE].[CANDIDATERECORDS];


CREATE TABLE [CANDIDATE].[CANDIDATERECORDS](
	[CANDIDATEID] [numeric](18, 0) NULL,
	[FIRSTNAME] [varchar](50) NULL,
	[LASTNAME] [varchar](50) NULL,
	[ADDRESS1] [varchar](100) NULL,
	[ADDRESS2] [varchar](100) NULL,
	[CITY] [varchar](100) NULL,
	[STATE] [varchar](2) NULL,
	[ZIPCODE] [varchar](20) NULL,
	[WORKPHONE] [varchar](20) NULL,
	[WORKPHONE_EXT] [varchar](10) NULL,
	[HOMEPHONE] [varchar](20) NULL,
	[CELLPHONE] [varchar](20) NULL,
	[FAX] [varchar](20) NULL,
	[EMAIL] [varchar](100) NULL,
	[ALTERNATEEMAIL] [varchar](100) NULL,
	[DATEUPDATED] [datetime] NULL,
	[DATEPROFILEUPDATED] [datetime] NULL,
	[DATEUSERFIELDUPDATED] [datetime] NULL,
	[CURRENTSALARY] [numeric](18, 0) NULL,
	[CURRENTSALARYPER] [varchar](20) NULL,
	[PREFERREDSALARYMIN] [numeric](18, 0) NULL,
	[PREFERREDSALARYPER] [varchar](20) NULL,
	[RESUMECOUNT] [numeric](18, 0) NULL,
	[DATECREATED] [datetime] NULL,
	[api_fromDate] [datetime] NULL,
	[api_toDate] [datetime] NULL,
	[LOAD_START] [datetime] NULL,
	[LOAD_END] [datetime] NULL,
	[DW_INSERT_TIME] [datetime] NULL,
	[PK_LKUP] [varchar](100) NULL


);


 

INSERT INTO [CANDIDATE].[CANDIDATERECORDS]
           ([CANDIDATEID]
           ,[FIRSTNAME]
           ,[LASTNAME]
           ,[ADDRESS1]
           ,[ADDRESS2]
           ,[CITY]
           ,[STATE]
           ,[ZIPCODE]
           ,[WORKPHONE]
           ,[WORKPHONE_EXT]
           ,[HOMEPHONE]
           ,[CELLPHONE]
           ,[FAX]
           ,[EMAIL]
           ,[ALTERNATEEMAIL]
           ,[DATEUPDATED]
           ,[DATEPROFILEUPDATED]
           ,[DATEUSERFIELDUPDATED]
           ,[CURRENTSALARY]
           ,[CURRENTSALARYPER]
           ,[PREFERREDSALARYMIN]
           ,[PREFERREDSALARYPER]
           ,[RESUMECOUNT]
           ,[DATECREATED]
           ,[api_fromDate]
           ,[api_toDate]
           ,[LOAD_START]
           ,[LOAD_END]
           ,[DW_INSERT_TIME]
           ,[PK_LKUP])
 

SELECT [CANDIDATEID]
           ,[FIRSTNAME]
           ,[LASTNAME]
           ,[ADDRESS1]
           ,[ADDRESS2]
           ,[CITY]
           ,[STATE]
           ,[ZIPCODE]
           ,[WORKPHONE]
           ,[WORKPHONE_EXT]
           ,[HOMEPHONE]
           ,[CELLPHONE]
           ,[FAX]
           ,[EMAIL]
           ,[ALTERNATEEMAIL]
           ,[DATEUPDATED]
           ,[DATEPROFILEUPDATED]
           ,[DATEUSERFIELDUPDATED]
           ,[CURRENTSALARY]
           ,[CURRENTSALARYPER]
           ,[PREFERREDSALARYMIN]
           ,[PREFERREDSALARYPER]
           ,[RESUMECOUNT]
           ,[DATECREATED]
           ,[api_fromDate]
           ,[api_toDate]
           ,[LOAD_START]
           ,[LOAD_END]
           ,[DW_INSERT_TIME]
           ,[PK_LKUP]
  FROM #CANDIDATERECORDStemp;
go

