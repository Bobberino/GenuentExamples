







/****** Script for SelectTopNRows command from SSMS  ******/

CREATE view [dbo].[v_sales_meetings] as 
WITH USERS AS (
SELECT DISTINCT UL.[USERID]
      ,[FIRSTNAME]
      ,[LASTNAME]
      ,[EMAIL]
      ,[DATECREATED]
      ,[ACTIVEFLAG]
      ,[DIVISION]

      ,[TITLE]
      ,[CITY]
      ,[STATE]
      ,[WORKPHONE]
      ,[EXTENSION]
      ,[CELLPHONE]
      ,[RECRUITERFLAG]
      ,[SALESFLAG]

  FROM [USERS].[USERSLIST] UL
 
 ) 




SELECT  [NOTEID]
      ,[ACTIONTYPE]
      ,C.[USERID]

      ,[USERFIRSTNAME]
      ,[USERLASTNAME]
      ,[CREATEDATE] 
      ,C.[CONTACTID]
      ,[CONTACTFIRSTNAME]
      ,[CONTACTLASTNAME]
	  ,[COMPANYNAME]
	  ,[COMPANYID]
      ,[DEPARTMENT]
      ,[JOBID]
      ,[JOBREFERENCENUMBER]
      ,[JOBTITLE]
      ,[CANDIDATEID]
      ,[CANDIDATEFIRSTNAME]
      ,[CANDIDATELASTNAME]
      ,[NOTEFIRST200CHARS]
      ,[api_fromDate]
      ,[api_toDate]
      ,actiondate
  FROM(SELECT [CONTACTID]
      ,[COMPANYNAME]
	  ,[COMPANYID]
      ,[DEPARTMENT]       
  FROM [CONTACT].[CONTACTRECORDS]) R
   left join [CONTACT].[contactACTIONS]   C
  ON C.CONTACTID = R.CONTACTID 
  LEFT JOIN USERS U ON C.USERID=U.USERID
 

  
 -- WHERE [NOTEFIRST200CHARS] NOT LIKE '%NEW CONTACT%'

go

