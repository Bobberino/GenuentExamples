
/****** Script for SelectTopNRows command from SSMS  ******/

CREATE   procedure [dbo].[candidateactions_dups] as 
DROP TABLE IF EXISTS #candidateactionstemp
select * into #candidateactionstemp from (

SELECT   [NOTEID]
      ,[ACTIONTYPE]
      ,[USERID]
      ,[USERFIRSTNAME]
      ,[USERLASTNAME]
      ,[CREATEDATE]
      ,[CANDIDATEID]
      ,[CANDIDATEFIRSTNAME]
      ,[CANDIDATELASTNAME]
      ,[JOBID]
      ,[JOBREFERENCENUMBER]
      ,[JOBTITLE]
      ,[CONTACTID]
      ,[CONTACTFIRSTNAME]
      ,[CONTACTLASTNAME]
      ,[NOTEFIRST200CHARS]
      ,max([api_fromDate]) [api_fromDate]
      ,max([api_toDate]) [api_toDate]
      ,max([LOAD_START]) [LOAD_START]
      ,max([LOAD_END]) [LOAD_END]
      ,max([DW_INSERT_TIME]) [DW_INSERT_TIME]
	 ,   PK_LKUP
  FROM [RPT_JobDivaAPI].[CANDIDATE].[CANDIDATEACTIONS]
  group by [NOTEID]
      ,[ACTIONTYPE]
      ,[USERID]
      ,[USERFIRSTNAME]
      ,[USERLASTNAME]
      ,[CREATEDATE]
      ,[CANDIDATEID]
      ,[CANDIDATEFIRSTNAME]
      ,[CANDIDATELASTNAME]
      ,[JOBID]
      ,[JOBREFERENCENUMBER]
      ,[JOBTITLE]
      ,[CONTACTID]
      ,[CONTACTFIRSTNAME]
      ,[CONTACTLASTNAME]
      ,[NOTEFIRST200CHARS]
	   ,   PK_LKUP)
	  a ;

	  drop table     [RPT_JobDivaAPI].[CANDIDATE].[CANDIDATEACTIONS];

	  select * into     [RPT_JobDivaAPI].[CANDIDATE].[CANDIDATEACTIONS] from #candidateactionstemp;
go

