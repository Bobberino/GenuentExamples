
/****** Script for SelectTopNRows command from SSMS  ******/

CREATE view [dbo].[v_candidate_meetings] as /****** Script for SelectTopNRows command from SSMS  ******/

WITH USERS AS (
SELECT DISTINCT UL.[USERID]
      ,[FIRSTNAME]
      ,[LASTNAME]
      ,[EMAIL]
      ,[DATECREATED]
      ,[ACTIVEFLAG]
      ,[DIVISION]
	  ,[COMPANY]
	  ,[FUNCTION]
	  ,[LOCATION]
      ,[TITLE]
      ,[CITY]
      ,[STATE]
      ,[WORKPHONE]
      ,[EXTENSION]
      ,[CELLPHONE]
      ,[RECRUITERFLAG]
      ,[SALESFLAG]

  FROM [USERS].[USERSLIST] UL
  LEFT JOIN (SELECT DISTINCT   
       [USERID]
      ,[USERNAME]
      ,[GROUPLISTNAME]
		,[COMPANY]= TRIM(CASE LEN([GROUPLISTNAME]) - LEN(REPLACE([GROUPLISTNAME],'-',''))
						WHEN 0 THEN ParseName(Replace([GROUPLISTNAME],' ','.'),2)  
						WHEN 1 THEN   ParseName(Replace([GROUPLISTNAME],'-','.'),2) 
						WHEN 2 THEN ParseName(Replace([GROUPLISTNAME],'-','.'),3)  
					END )
 		,[FUNCTION]=TRIM(CASE LEN([GROUPLISTNAME]) - LEN(REPLACE([GROUPLISTNAME],'-',''))
						WHEN 0 THEN ParseName(Replace([GROUPLISTNAME],' ','.'),1)  
						WHEN 1 THEN   ParseName(Replace([GROUPLISTNAME],'-','.'),1) 
						WHEN 2 THEN ParseName(Replace([GROUPLISTNAME],'-','.'),2)  
					END )
		,[LOCATION]=TRIM(CASE LEN([GROUPLISTNAME]) - LEN(REPLACE([GROUPLISTNAME],'-',''))
						WHEN 0 THEN ParseName(Replace([GROUPLISTNAME],' ','.'),0)  
						WHEN 1 THEN   ParseName(Replace([GROUPLISTNAME],'-','.'),0) 
						WHEN 2 THEN ParseName(Replace([GROUPLISTNAME],'-','.'),1)  
					END )
  FROM [USERS].[USERGROUPLISTS]
  WHERE TRIM(CASE LEN([GROUPLISTNAME]) - LEN(REPLACE([GROUPLISTNAME],'-',''))
						WHEN 0 THEN ParseName(Replace([GROUPLISTNAME],' ','.'),0)  
						WHEN 1 THEN   ParseName(Replace([GROUPLISTNAME],'-','.'),0) 
						WHEN 2 THEN ParseName(Replace([GROUPLISTNAME],'-','.'),1)  
					END ) IS NOT NULL

  ) SAL_REC ON UL.USERID = SAL_REC.USERID 
  --WHERE RECRUITERFLAG = '1'
   -- AND ACTIVEFLAG= '1'
   ) 




SELECT [NOTEID]
      ,[ACTIONTYPE]
      ,C.[USERID]
	  ,[DIVISION]
	  ,[COMPANY]
	  ,[FUNCTION]
	  ,[LOCATION]
      ,[TITLE]
      ,[CITY]
      ,[STATE]
	  ,[USERFIRSTNAME]
      ,[USERLASTNAME]
      ,[CREATEDATE]
      ,[CANDIDATEID]
      ,[CANDIDATEFIRSTNAME]
      ,[CANDIDATELASTNAME]
      ,[JOBID]
      ,[JOBREFERENCENUMBER]
      ,[JOBTITLE]
      ,[CONTACTID]
      ,[CONTACTFIRSTNAME]
      ,[CONTACTLASTNAME]
      ,[NOTEFIRST200CHARS]
      ,[api_fromDate]
      ,[api_toDate]
 
  FROM CANDIDATE.[CandidateActions]  c
  LEFT JOIN USERS U ON C.USERID=U.USERID
go

