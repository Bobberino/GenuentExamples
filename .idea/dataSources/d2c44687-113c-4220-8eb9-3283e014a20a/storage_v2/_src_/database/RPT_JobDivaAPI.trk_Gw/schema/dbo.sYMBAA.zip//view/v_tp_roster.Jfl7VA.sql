




 CREATE view [dbo].[v_tp_roster] as 
 

select distinct firstname, lastname, city, DATECREATED, email, candidateid,
case when firstname + ' ' + lastname in (
'Vismaya Kondapalli',
'Joseph Price',
'Lance Bungay',
'Seth I Etienne',
'Deniz Felsman',
'Andrew Crawford',
'Vicki Nguyen',
'Paul Dang',
'Ryan Chacko',
'Benjamin Quach',
'Sally Chiu') then 'Cohort1'
when firstname + ' ' + lastname  in 
('Melisa Galhena',
'Muneeza Anees',
'Elvis Alvarez',
'Bismah Khan',
'Khoi Nguyen',
'Jacob D Brijalba',
'Saboor Salahuddin',
'David Vasco',
'Oscar Caballero',
'Kirby Nguyen',
'Jose Cerna',
'Rafael Torres',
'Frank Martinez',
'Erin Farmer') then 'Cohort2'
when firstname + ' ' + lastname  in 
(
'Geleela Mengistu',
'Kevin Mathew',
'Richard Nguyen',
'Marcos Velazquez',
'Ithar Katami',
'Joseph Becker',
'Sarina Proctor',
'Athira Nair',
'Suleman Tauheed',
'Anish Manuel',
'DeBari Gbaanador',
'Nathan Oliphant',
'Shilpi Bhambri',
'Dan Dinh',
'Lauren Price') then 'Cohort3'
when firstname + ' ' + lastname in ('Alexander Rulon ',
'Allison Wright ',
'Ayan Karim ',
'Della Leahy ',
'Jacob Hitt ',
'Jonathan Walthour ',
'Kayger Duran ',
'Kristie Peyton ',
'Max Wang ',
'Nabta Hamid ',
'Paul Cheakalos ',
'Paul Yotka ',
'Phuong Nguyen ',
'Salma Roshdi ',
'Waleed Qureshi') then 'Cohort 5'
end cohort

  FROM [RPT_JobDivaAPI].[CANDIDATE].[CANDIDATERECORDS]
--where email like '%talentpath.com%' 
 where candidateid not in ('134446224636','1682631696812','7104459328194','6989936119079','9698201248871','8797017222213','8835340495875',
'820705283350',
'9767884526235', '1245142141648','8472447816592','7365047131209','786714827027','8878185327044',
'8824209094668','1865944738654','8709650914771','8042075797506','2419025483126','6135913555922',
'221576873788','5638244392018','3443740917542') and 
firstname + ' ' + lastname in ('Melisa Galhena','Vicki Nguyen',
'Vismaya Kondapalli',
'Joseph Price',
'Lance Bungay',
'Seth I Etienne',
'Deniz Felsman',
'Andrew Crawford',
'Paul Dang',
'Ryan Chacko',
'Benjamin Quach',
'Sally Chiu',
'Muneeza Anees',
'Elvis Alvarez',
'Bismah Khan',
'Khoi Nguyen',
'Jacob D Brijalba',
'Saboor Salahuddin',
'David Vasco',
'Oscar Caballero',
'Kirby Nguyen',
'Jose Cerna',
'Rafael Torres',
'Frank Martinez',
'Erin Farmer',
'Geleela Mengistu',
'Kevin Mathew',
'Richard Nguyen',
'Marcos Velazquez',
'Ithar Katami',
'Joseph Becker',
'Sarina Proctor',
'Athira Nair',
'Suleman Tauheed',
'Anish Manuel',
'DeBari Gbaanador',
'Nathan Oliphant',
'Shilpi Bhambri',
'Dan Dinh',
'Lauren Price',
'Alexander Rulon ',
'Allison Wright ',
'Ayan Karim ',
'Della Leahy ',
'Jacob Hitt ',
'Jonathan Walthour ',
'Kayger Duran ',
'Kristie Peyton ',
'Max Wang ',
'Nabta Hamid ',
'Paul Cheakalos ',
'Paul Yotka ',
'Phuong Nguyen ',
'Salma Roshdi ',
'Waleed Qureshi ') or CANDIDATEID in ('9928705742990')

Union 
select distinct
firstname, lastname, city, DATECREATED, email, candidateid,
'Cohort 4' as cohort
FROM [RPT_JobDivaAPI].[CANDIDATE].[CANDIDATERECORDS]
where candidateid in (SELECT ACT_CANDIDATEID 
FROM v_job_stage 
WHERE  email in ('BJameson@talentpath.com','SSaksFithian@talentpath.com')
or( isnull(ACT_LOCATION,0)   in ('hb-ca') and  JOB_DIVISION = 'Talent Path' )
)

 go

